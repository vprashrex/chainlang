"""Spark SQL agent."""
