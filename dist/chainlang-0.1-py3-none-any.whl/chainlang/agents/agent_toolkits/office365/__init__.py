"""Office365 toolkit."""
